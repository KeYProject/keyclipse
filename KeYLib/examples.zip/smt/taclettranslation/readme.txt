This folder contains examples of proofing problems by means of passing taclets to the external prover. 
