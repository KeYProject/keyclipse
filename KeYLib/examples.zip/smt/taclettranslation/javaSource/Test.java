/**
Simple test class for testing the external provers.
*/

public class Test
{
  public static int D;
  public static int E(){return D;}
  public Test(){
 }
  private int A;
  public  int B;
  public   Test F;
  public  Test [] G;

  public int C(boolean b) {return A;}

} 
