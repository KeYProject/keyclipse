example.name = Simple Array Reversal
example.path = Algorithms
example.additionalFile.1 = src/ReverseArray.java
example.file = reverseArray.key
# Please ensure that the following file is included into the group reload_examples within automaticJAVADL.txt.
example.proofFile = reverseArray.proof

This is an example from the early days of KeY.

An array a is reversed. This is done by swapping the first (a.length/2) elements 
with their counterparts from the other end of the array.
