example.name = Cell
example.path = Dynamic Frames
example.additionalFile.2 = src/CellClient.java
example.additionalFile.1 = src/Cell.java

The examples from the paper "An Automatic Verifier for Java-like Programs Based on Dynamic Frames" by Jan Smans, Bart Jacobs, Frank Piessens and Wolfram Schulte.

All proof obligations are verifiable without user interaction.
