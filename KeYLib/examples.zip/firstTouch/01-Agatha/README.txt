example.name = Aunt Agatha
example.path = Getting Started

Dreadbury Mansion (aka Aunt Agatha)

This is a purely first-order predicate logic problem from the TPTP library.

Someone who lives in Dreadbury Mansion killed Aunt Agatha. Agatha, the butler, and Charles live in Dreadbury Mansion, and are the only people who live therein. A killer always hates his victim, and is never richer than his victim. Charles hates no one that Aunt Agatha hates. Agatha hates everyone except the butler. The butler hates everyone not richer than Aunt Agatha. The butler hates everyone Aunt Agatha hates. No one hates everyone. Agatha is not the butler. Therefore : Agatha killed herself.

File: PUZ001+1 Released TPTP v2.0.0
Rating: 0.26 (TPTP v5.5.0)
