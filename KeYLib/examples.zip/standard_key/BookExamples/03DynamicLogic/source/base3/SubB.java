public class SubB extends Base {

    public int nextId (int i) {
        return super. nextId (i )+1;
    }

}
