public class SubA extends Base {

}
