public class Base {

    public int nextId (int i) {
        return ++ i;
    }

}
