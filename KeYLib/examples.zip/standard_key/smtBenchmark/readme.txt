This folder contains Problems, that can be used to test external Prover.
It only contains Problems using typed predicate logic without heuristics. 
No updates or programs are used in these Problems.
