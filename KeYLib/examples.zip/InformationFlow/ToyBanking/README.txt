example.path = Information Flow
example.name = Toy Bank
example.additionalFile.1 = src/banking_example/Bank.java
example.additionalFile.2 = src/banking_example/UserAccount.java
example.additionalFile.3 = src/banking_example/BankAccount.java

Information flow example.

The example is a toy implementation of a banking system. It is ensured that customers may observe only data of their own user- and bank-accounts. Employees my observe everything but the passwords of the customers. Further, customers may see their user account only after a successful log in.


