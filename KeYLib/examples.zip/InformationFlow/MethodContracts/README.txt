example.path = Information Flow
example.name = Method Calls
example.additionalFile.1 = src/contract/IFMethodContract.java


Information flow examples.

A collection of several examples showing the usage of information flow method contracts.

The information flow proof obligations of all secure examples can be proved fully automatically using the macro "Full Information Flow Auto Pilot".
 
 
