example.path = Information Flow
example.name = Block Contracts
example.additionalFile.1 = src/contract/IFBlockExamples.java
example.additionalFile.2 = src/contract/IFEfficiencyExamples.java


Information flow examples.

A collection of several examples showing the usage of information flow block contracts.
