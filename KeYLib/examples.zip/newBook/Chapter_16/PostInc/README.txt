example.name = Listing 16.1 - PostInc
example.path = The KeY Book/Chapter 16 - Formal Verification with KeY: A Tutorial
example.file=PostInc.java
example.additionalFile.1=PostInc.java

This example contains the code of Listing 16.1 of the KeY book.

The proof completes automatically with standard proof settings.
