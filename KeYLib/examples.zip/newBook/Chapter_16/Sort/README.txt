example.name = Listing 16.2 - Sort
example.path = The KeY Book/Chapter 16 - Formal Verification with KeY: A Tutorial
example.file=Sort.java
example.additionalFile.1=Sort.java

This example contains the code of Listing 16.2 of the KeY book.

Both proofs complete automatically with standard proof settings.
