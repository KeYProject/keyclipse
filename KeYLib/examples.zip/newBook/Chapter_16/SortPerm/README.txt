example.name = Listing 16.3 - SortPerm
example.path = The KeY Book/Chapter 16 - Formal Verification with KeY: A Tutorial
example.file=SortPerm.java
example.additionalFile.1=SortPerm.java

This example contains the code of Listing 16.3 of the KeY book.

The proof of the contract for max completes automatically with standard proof settings. For the proof of the contract for sort follow the instructions on pages 564-565 of the KeY book.
