example.name = Building First-order Proofs
example.path = New Book/Using KeY
example.file = projection.key
example.additionalFile.1 = projection.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.

files: projection.key

Wolfgang Ahrendt, Sarah Grebing
