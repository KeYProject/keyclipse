example.name = Further Features
example.path = New Book/Using KeY
example.file = generalProjection.key
example.additionalfile.1 = generalProjection.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.

files: generalProjection.key

Wolfgang Ahrendt, Sarah Grebing
