example.name = Building Propositional Proofs
example.path = New Book/Using KeY
example.file = andCommutes.key
example.additionalFile.1 = andCommutes.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.

files: andCommutes.key

Wolfgang Ahrendt, Sarah Grebing
