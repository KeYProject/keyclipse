example.name = executeByProving.key
example.path = The KeY Book/Chapter 15 - Using the KeY Prover/Building Dynamic Logic Proofs
example.file = executeByProving.key
example.additionalFile.1 = executeByProving.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.


Wolfgang Ahrendt, Sarah Grebing
