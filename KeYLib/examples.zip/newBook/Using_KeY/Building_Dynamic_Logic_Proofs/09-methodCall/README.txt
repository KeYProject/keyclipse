example.name = methodCall.key
example.path = The KeY Book/Chapter 15 - Using the KeY Prover/Building Dynamic Logic Proofs/methodCall
example.file = methodCall.key
example.additionalFile.1 = methodExample/Person.java
example.additionalFile.2 = methodCall.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.


Wolfgang Ahrendt, Sarah Grebing
