example.name = methodCall.key
example.path = The KeY Book/Chapter 15 - Using the KeY Prover/Building Dynamic Logic Proofs/methodCall2
example.file = methodCall2.key
example.additionalFile.1 = methodExample/Person.java
example.additionalFile.2 = methodCall2.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.


Wolfgang Ahrendt, Sarah Grebing
