example.name = Building Dynamic Logic Proofs - DL Examples
example.path = New Book/Using KeY
example.additionalFile.1 = activeStmt.key
example.additionalFile.2 = exchange.key
example.additionalFile.3 = executeByProving.key
example.additionalFile.4 = postIncrement.key
example.additionalFile.5 = postIncrNoUpdate.key 
example.additionalFile.6 = quantifyProgVals.key
example.additionalFile.7 = updates.key


This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.

files: 

Wolfgang Ahrendt, Sarah Grebing
