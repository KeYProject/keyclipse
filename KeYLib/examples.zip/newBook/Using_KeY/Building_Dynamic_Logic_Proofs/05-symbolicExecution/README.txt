example.name = symbolicExecution.key
example.path = New Book/Using KeY/Building Dynamic Logic Proofs
example.file = symbolicExecution.key
example.additionalFile.1 = symbolicExecution.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.


Wolfgang Ahrendt, Sarah Grebing