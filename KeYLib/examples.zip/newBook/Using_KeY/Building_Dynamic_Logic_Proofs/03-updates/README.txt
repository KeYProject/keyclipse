example.name = updates.key
example.path = New Book/Using KeY/Building Dynamic Logic Proofs
example.file = updates.key
example.additionalFile.1 = updates.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.


Wolfgang Ahrendt, Sarah Grebing