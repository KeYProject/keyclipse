example.name = Building Dynamic Logic Proofs - Calling Methods
example.path = The KeY Book/Chapter 15 - Using the KeY Prover
example.additionalFile.1 = methodCall.key
example.additionalFile.2 = methodCall2.key
example.additionalFile.3 = methodExample/Person.java

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.

files: 
methodCall.key
methodCall2.key
Person.java

Wolfgang Ahrendt, Sarah Grebing
