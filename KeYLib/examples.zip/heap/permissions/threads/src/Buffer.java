public class Buffer {
    int inp;
    int outa;
    int outb;
}
