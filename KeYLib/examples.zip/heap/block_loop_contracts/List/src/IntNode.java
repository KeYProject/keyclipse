
public final class IntNode {
    public /*@nullable@*/ IntNode next;
    public int data;
}
