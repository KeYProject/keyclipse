/* This class is now added with a strictly_pure 
   modifier */

/*@ strictly_pure*/ class StrictlyPureClass {

   //@ ensures true;
   void thisMethodIsStrictlyPureByDefault();

}
