class TreeException extends Exception {
}
