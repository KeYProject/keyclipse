example.name = List with Ghosts
example.path = Dynamic Frames
example.additionalFile.2 = src/ArrayList.java
example.additionalFile.1 = src/List.java

A slightly modified subset of the "list" example, demonstrating the use of ghost fields instead of model fields for framing.

All proof obligations are verifiable without user interaction.
