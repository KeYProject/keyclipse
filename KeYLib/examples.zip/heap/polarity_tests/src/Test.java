public class Test {
    int x;

    //@ requires true;
    void m(){x=5;}
}