public class IniSub extends Initially {

  public IniSub (){
    super(5);
  }

}
