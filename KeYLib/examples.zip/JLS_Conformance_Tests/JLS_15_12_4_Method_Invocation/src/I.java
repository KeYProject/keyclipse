public interface I {

    void noOneWantsToImplementMe();

}